<?php
$num = 1;
foreach ($users as $user) {
	$id = $user['id'];
	$username = $user['username'];
	$pass = $user['password'];
?>
<tr>
	<th scope='row'><?= $num++ ?></th>
	<td><?= $username ?></td>
	<td><?= $pass ?></td>
	<td>
		<button id='edit-user' class='btn btn-warning' value="<?= $id ?>" data-bs-toggle='modal' data-bs-target='#exampleModal'>Edit</button>
		<button id='delete-user' class='btn btn-danger' value="<?= $id ?>">Delete</button>
	</td>
</tr>
<?php } ?>
