<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		  content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
	<title>Login</title>
	<style>
		input{
			margin-bottom: 20px;
		}
		form{
			max-width: 350px !important;
			margin-top: 200px !important;
		}
	</style>
</head>
<body>
<form action="login/auth" method="post" class="container" style="margin: 0 auto">
	<input name="username" type="text" placeholder="Enter Username our Email" class="form-control">
	<input name="password" type="password" placeholder="Enter Password" class="form-control">
	<div class="form-check">
		<input class="form-check-input" type="checkbox" value="" id="flexCheckIndeterminate">
		<label class="form-check-label" for="flexCheckIndeterminate">
			Remember me
		</label>
	</div>
	<br>
	<?php if (isset($auth)){ ?>
	<a href="../" class="btn btn-danger">Back</a>
	<br>
	<?php }else{ ?>
	<input name="submit" type="submit" value="send" class="btn btn-primary">
	<?php } ?>
	<br>
	<?php echo validation_errors(); ?>
</form>
</body>
</html>
