<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		  content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
		  integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
			integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
			crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"
			integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

	<title>Users</title>
</head>
<body class="container">
<br>
<table class="table">
	<thead>
	<tr>
		<th scope="col">#</th>
		<th scope="col">Username</th>
		<th scope="col">Password</th>
		<th scope="col">Action</th>
	</tr>
	</thead>
	<tbody id="result">

	</tbody>

	<!-- Button trigger modal -->
	<button id="open-modal" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
		Add new
	</button>
	<br><br>

	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Adding new user</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<form action="" method="post" id="add-form">
					<div class="modal-body">
						<input type="hidden" id="id-update">
						<label for="">Username</label>
						<input type="text" name="username" class="form-control" id="username">
						<span id="alert-username" style="font-size: 12px; color: #df4759;"></span>
						<br>
						<label for="">Password</label>
						<input type="password" name="password" class="form-control" id="password">
						<span id="alert-password" style="font-size: 12px; color: #df4759;"></span>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
						<button type="button" class="btn btn-primary" id="add-new">Send Request</button>
						<button type="button" class="btn btn-primary" id="update-new" style="display: none">Update</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</table>

<!-- <botton id="refreh" class="btn btn-info">Refresh</botton> -->

</body>
<script>

	$(document).ready(function (){
		$.ajax({
			url: 'user/allUser',
			method: 'POST',
			success: function (values){
				$("#result").html(values)
			}
		})

		// Open modal (reset style after sending data)
		$("#open-modal").click(function () {
			// Setting btn
			$("#update-new").hide()
			$("#add-new").show()

			$("#add-form")[0].reset()
			$("#alert-username").html("")
			$("#alert-password").html("")
			$("#username").css('border','1px solid #ced4da')
			$("#password").css('border','1px solid #ced4da')
		})

		// Add new
		$("#add-new").click(function () {
			username = $("#username").val()
			password = $("#password").val()
			// Validation
			if (username == ''){
				$("#username").css('border','1px solid #df4759')
				$("#alert-username").html("This fild is required")
			}
			if (password == ''){
				$("#password").css('border','1px solid #df4759')
				$("#alert-password").html("This fild is required")
			}
			if (username != ''){
				$("#username").css('border','1px solid 	#42ba96')
				$("#alert-username").html("")
			}
			if (password != ''){
				if (password.length < 8){
					$("#password").css('border','1px solid #df4759')
					$("#alert-password").html("At least 8 characters")
				}else{
					$("#password").css('border','1px solid 	#42ba96')
					$("#alert-password").html("")
				}
			}

			// Send Request
			if (username != '' && password != '' && password.length >= 8){
				$.ajax({
					url: 'user/addUser',
					method: 'POST',
					data: {username:username , password:password},
					success: function (data) {
						swal("Good job!", "Added your new post!", "success")
						// $("#exampleModal").hide()
						
						// Request ajax
						$.ajax({
							url: 'user/allUser',
							method: 'POST',
							success: function (values){
								$("#result").html(values)
						}})
					}
				})
			}
		})

		// Delete User
		$(document).on('click','#delete-user',function () {
			$.ajax({
				url: 'user/deleteUser',
				method: 'POST',
				data: {data:$(this).val()},
				success: function (){
					// Alert
					swal("Good job!", "Deleted successfully!", "success")

					// Request ajax
					$.ajax({
						url: 'user/allUser',
						method: 'POST',
						success: function (values){
							$("#result").html(values)
						}
					})
				}
			})
		})

		// Edit User
		$(document).on('click','#edit-user',function(){
			var id = $(this).val()

			// Getting User information
			$.ajax({
				url: 'user/singleUser',
				method: 'POST',
				data: {id : id},
				success: function (values) {
					var obj = jQuery.parseJSON(values)
					$("input#id-update").val(obj.id)
					$("input#username").val(obj.username)
					$("input#password").val(obj.password)
					$("#exampleModalLabel").html("Updating user : " + obj.username)
					$("#add-new").hide()
					$("#update-new").show()
				}
			})
		})

		// Updating User
		$("#update-new").click(function () {
			var id = $("#id-update").val()
			var username = $("#username").val()
			var password = $("#password").val()

			$.ajax({
				url: 'user/updateUser',
				method: 'post',
				data: {id : id , username: username , password : password},
				success:function () {
					swal("Good job!", "Updated successfully!", "success")
					// Request ajax
					$.ajax({
						url: 'user/allUser',
						method: 'POST',
						success: function (values){
							$("#result").html(values)
					}})
				}
			})
		})
	})
</script>
</html>
