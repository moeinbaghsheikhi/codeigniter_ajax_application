<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
	public function index()
	{
		$this->load->view('user/index');
	}

	public function allUser()
	{
		$this->load->model('user_model', 'user');
		$data = $this->user->fetchAll();
		$users = $data->result_array();
		$this->load->view('form/list' , array('users' => $users));
	}

	public function singleUser()
	{
		$datas = $this->input->post();
		foreach ($datas as $data){}
		$this->load->model('user_model' , 'user');
		$results = $this->user->fetchRow($data)->result_array();
		foreach ($results as $result) {}
		$result = json_encode($result);
		echo $result;
	}

	public function addUser()
	{
		$data = $this->input->post();
		$this->load->model('user_model' , 'user');
		$this->user->addUser($data);
	}

	public function deleteUser()
	{
		$datas = $data = $this->input->post();
		foreach ($datas as $data){}
		$this->load->model('user_model','user');
		$this->user->delete($data);
	}

	public function updateUser()
	{
		$data = $this->input->post();
		$this->load->model('user_model','user');
		$this->user->updateUser($data);
	}
}
