<?php

class user_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function fetchAll(){
		return $this->db->get('tbl_users');
	}

	public function fetchRow($id){
		return $this->db->get_where('tbl_users',array('id' => $id));
	}

	public function addUser($data){
		$this->db->insert('tbl_users' , $data);
	}

	public function delete($id){
		$this->db->delete('tbl_users',array('id' => $id));
	}

	public function updateUser($data){
		$this->db->update('tbl_users',$data,array('id' => $data['id']));
	}
}
